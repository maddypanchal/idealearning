﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Public_IdeaLogin : System.Web.UI.Page
{
    #region"Varible"

    #endregion
    #region"Page Load Event "
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    #endregion
    #region" Student varify"
    protected void btnStudent_Click(object sender, EventArgs e)
    {

    }
    #endregion
    #region"Employee Varify"
    
    protected void btnEmpSubmit_Click(object sender, EventArgs e)
    {

    }
    #endregion
    #region"Admin Varify"

    protected void btnAdminLoign_Click(object sender, EventArgs e)
    {

    }
    #endregion
   
}